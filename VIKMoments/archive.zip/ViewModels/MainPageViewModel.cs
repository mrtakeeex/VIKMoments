using Template10.Mvvm;
using System;
using System.Threading.Tasks;
using Template10.Services.NavigationService;
using VIKMoments.Models;
using System.Collections.ObjectModel;
using VIKMoments.Services.InstagramApiServices;
using Windows.UI.Xaml.Controls;
using VIKMoments.Views;
using Windows.UI.Popups;
using Template10.Behaviors;
using System.ComponentModel;

namespace VIKMoments.ViewModels
{
    public class MainPageViewModel : ViewModelBase
    {
        public ObservableCollection<Follower> FollowedList;
        public ObservableCollection<Follower> FollowersList;
        public Profile _ProfileData;
        public Profile ProfileData
        {
            get { return _ProfileData; }
            set { Set(ref _ProfileData, value); }
        }
        public static string token { get; set; }

        public static bool loggedIn;

        private readonly IInstagramApiService _instagramApiService;
        public MainPageViewModel(IInstagramApiService instagramApiService)
        {
            _instagramApiService = instagramApiService;

            loggedIn = true;
            FollowersList = new ObservableCollection<Follower>();
            FollowedList = new ObservableCollection<Follower>();
        }

        public static async void login()
        {
            String _callbackUriString = "https://bmecookbook.azurewebsites.net/";
            Uri _callbackUri = new Uri(_callbackUriString);

            string startURL = "https://api.instagram.com/oauth/authorize/?client_id=18ff800b4997466ea46d8ce12920559c&redirect_uri="
                + Uri.EscapeDataString(_callbackUriString) + "&response_type=token" + "&scope=basic+public_content+follower_list+comments+relationships+likes";

            System.Uri startURI = new System.Uri(startURL);

            string result;

            try
            {
                var webAuthenticationResult =
                    await Windows.Security.Authentication.Web.WebAuthenticationBroker.AuthenticateAsync(
                    Windows.Security.Authentication.Web.WebAuthenticationOptions.None,
                    startURI, _callbackUri);

                switch (webAuthenticationResult.ResponseStatus)
                {
                    case Windows.Security.Authentication.Web.WebAuthenticationStatus.Success:
                        // Successful authentication. 
                        result = webAuthenticationResult.ResponseData.ToString();
                        token = result.Split('=')[1];
                        loggedIn = true;
                        break;
                    case Windows.Security.Authentication.Web.WebAuthenticationStatus.ErrorHttp:
                        // HTTP error. 
                        result = webAuthenticationResult.ResponseErrorDetail.ToString();
                        loggedIn = false;
                        break;
                    default:
                        // Other error.
                        result = webAuthenticationResult.ResponseData.ToString();
                        loggedIn = false;
                        break;
                }
            }
            catch (Exception ex)
            {
                // Authentication failed. Handle parameter, SSL/TLS, and Network Unavailable errors here. 
                result = ex.Message;
            }
        }

        public static void logout(object sender, object e)
        {
            MainPageViewModel.token = null;
            MainPageViewModel.loggedIn = false;

            MessageDialogAction msg = new MessageDialogAction();
            msg.Title = "You successfully logged out!";
            msg.Content = "Please login if you want to use the application!";
            msg.Execute(sender, e);
        }

        //public override async Task OnNavigatingFromAsync(NavigatingEventArgs args)
        //{
        //    args.Cancel = false;
        //    await Task.CompletedTask;
        //}

        public async Task getMyProfile()
        {
            ProfileData = await _instagramApiService.GetMyProfileAsnyc(token);
        }

        public async Task getFollowed()
        {
            FollowedList.Clear();
            FollowedList = await _instagramApiService.GetFollowedAsnyc(token);
        }

        public async Task getFollowers()
        {
            FollowersList.Clear();
            FollowersList = await _instagramApiService.GetFollowersAsnyc(token);   
        }

        public async void Details(object sender, ItemClickEventArgs args)
        {
            // TODO: profile
            var follower = (Follower)args.ClickedItem;
            var dialog = new MessageDialog("You clicked on user with ID " + follower.id);
            await dialog.ShowAsync();
        }

        //public void GotoDetailsPage() =>
        //    NavigationService.Navigate(typeof(Views.DetailPage));

        //public void GotoSettings() =>
        //    NavigationService.Navigate(typeof(Views.SettingsPage), 0);

        //public void GotoPrivacy() =>
        //    NavigationService.Navigate(typeof(Views.SettingsPage), 1);

        //public void GotoAbout() =>
        //    NavigationService.Navigate(typeof(Views.SettingsPage), 2);
    }
}

