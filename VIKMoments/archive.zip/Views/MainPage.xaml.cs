using VIKMoments.Services.InstagramApiServices;
using VIKMoments.ViewModels;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using VIKMoments.Models;
using Template10.Behaviors;

namespace VIKMoments.Views
{
    public sealed partial class MainPage : Page
    {
        public MainPageViewModel ViewModel;
        //public MainPageViewModel ViewModel => (MainPageViewModel)DataContext;

        public MainPage()
        {
            InitializeComponent();
            this.DataContext = ViewModel;
            NavigationCacheMode = Windows.UI.Xaml.Navigation.NavigationCacheMode.Enabled;            

            this.ViewModel = new MainPageViewModel(new InstagramApiService(MainPageViewModel.token));
    }


        private async void rootPivot_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (MainPageViewModel.loggedIn)
            {
                switch (rootPivot.SelectedIndex)
                {
                    case 0:
                        // News feed
                        break;
                    case 1:
                        // My profile
                        await ViewModel.getMyProfile();
                        break;
                    case 2:
                        // Followed
                        await ViewModel.getFollowed();
                        followedListView.ItemsSource = ViewModel.FollowedList;
                        break;
                    case 3:
                        // Followers
                        await ViewModel.getFollowers();
                        followedByListView.ItemsSource = ViewModel.FollowersList;
                        break;
                }
            }
            else
            {
                MessageDialogAction msg = new MessageDialogAction();
                msg.Title = "Please log in!";
                msg.Content = "You are currently logged out.";
                msg.Execute(sender, e);
            }

        }
    }
}
